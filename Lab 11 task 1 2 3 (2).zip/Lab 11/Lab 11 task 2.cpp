#include <iostream>
using namespace std;


struct User {
    string name;
};

// Function to simulate user login
bool loginUser(User &user) {
    string enteredUsername;

    // Prompt the user to enter their username
    cout << "Enter your username: ";
    getline(cin, enteredUsername);

    // Simulate authentication 
    if (enteredUsername == user.name) {
        return true;  
    }
    else {
        return false; 
    }
}

int main() {
    User user;

    // Set a predefined username
    user.name = "user123";
    
    bool loginSuccess = loginUser(user);

    // Display personalized message based on login result
    if (loginSuccess) {
        cout << "\nWelcome, " << user.name << "!" << endl;
    } else {
        cout << "\nLogin failed. Please check your username." << endl;
    }

    return 0;
}