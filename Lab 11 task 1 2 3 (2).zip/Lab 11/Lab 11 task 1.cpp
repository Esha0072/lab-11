#include <iostream>
using namespace std;

struct Book {
    string title;
    string author;
    int year_of_publication;
    int num_of_pages;
};

// Function to input book information
void inputBookInfo(Book &book) {
    cout << "Enter the title of the book: ";
    getline(cin, book.title); 
    cout << "Enter the author of the book: ";
    getline(cin, book.author);
    cout << "Enter the year of publication: ";
    cin >> book.year_of_publication;
    cout << "Enter the number of pages: ";
    cin >> book.num_of_pages;
    cin.ignore();  
}

// Function to display book information
void displayBookInfo(const Book &book) {
    cout << "\nBook Information:" << endl;
    cout << "Title: " << book.title << endl;
    cout << "Author: " << book.author << endl;
    cout << "Year of Publication: " << book.year_of_publication << endl;
    cout << "Number of Pages: " << book.num_of_pages << endl;
}

int main() {
    const int numBooks = 5;
    Book books[numBooks]; // Array of 5 books

    // Input information for each book
    for (int i = 0; i < numBooks; ++i) {
        cout << "\nEnter details for Book " << (i + 1) << ":\n";
        inputBookInfo(books[i]);
    }

    // Display information for each book
    cout << "\nDisplaying information for all books:\n";
    for (int i = 0; i < numBooks; ++i) {
        cout << "\nDetails of Book " << (i + 1) << ":\n";
        displayBookInfo(books[i]);
    }

    return 0;
}