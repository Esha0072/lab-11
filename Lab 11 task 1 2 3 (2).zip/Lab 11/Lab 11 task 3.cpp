#include <iostream>
#include <algorithm>  // For the max() function

using namespace std;

// Define the StudentGrading structure
struct StudentGrading {
    string name;
    string sapID;
    string address;
    string department;
    int marksSubject1;
    int marksSubject2;
    
    // Function to calculate the maximum marks between two subjects
    int calculateMaxMarks() const {
        return max(marksSubject1, marksSubject2);
    }

    // Function to display student information
    void displayStudent() const {
        cout << "\nStudent Information:" << endl;
        cout << "Name: " << name << endl;
        cout << "SAP ID: " << sapID << endl;
        cout << "Address: " << address << endl;
        cout << "Department: " << department << endl;
        cout << "Marks in Subject 1: " << marksSubject1 << endl;
        cout << "Marks in Subject 2: " << marksSubject2 << endl;
        cout << "Maximum Marks: " << calculateMaxMarks() << endl;
    }
};

int main() {
    const int numStudents = 5;
    StudentGrading students[numStudents];  // Array to hold 5 students

    // Input information for each student
    for (int i = 0; i < numStudents; ++i) {
        cout << "\nEnter details for Student " << (i + 1) << ":\n";

        cout << "Enter name: ";
        getline(cin, students[i].name);

        cout << "Enter SAP ID: ";
        getline(cin, students[i].sapID);

        cout << "Enter address: ";
        getline(cin, students[i].address);

        cout << "Enter department: ";
        getline(cin, students[i].department);

        cout << "Enter marks for Subject 1: ";
        cin >> students[i].marksSubject1;

        cout << "Enter marks for Subject 2: ";
        cin >> students[i].marksSubject2;

        cin.ignore();  
    }

    // Display information for each student
    cout << "\nDisplaying student details:\n";
    for (int i = 0; i < numStudents; ++i) {
        students[i].displayStudent();
    }

    return 0;
}